package org.callcenter.ejb;

public class Dispatcher {

}
