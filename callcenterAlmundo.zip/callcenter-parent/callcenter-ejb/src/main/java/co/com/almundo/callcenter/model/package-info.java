/**
 * 
 */
/**
 * @author lmarin
 *
 */
package co.com.almundo.callcenter.model;