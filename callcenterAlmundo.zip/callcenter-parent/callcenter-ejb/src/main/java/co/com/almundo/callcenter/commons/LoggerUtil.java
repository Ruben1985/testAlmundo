package co.com.almundo.callcenter.commons;

import java.io.Serializable;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class LoggerUtil implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private java.net.URL url = Thread.currentThread().getContextClassLoader().getResource("log4j.xml");
	
	public static Logger log = null;
	
	public LoggerUtil(Class<?> loggerClass){
		DOMConfigurator.configure(url);
		log = Logger.getLogger(loggerClass);
	}
	
	public static LoggerUtil getLogger(Class<?> loggerClass){
		return new LoggerUtil(loggerClass);
	}
	
	public void error(String msg){
		log.error(msg);
	}
	
	public void error(String msg, Throwable ex){
		log.error(msg, ex);
	}
	
	public void debug(String msg){
		log.debug(msg);
	}
	
	
	public void info(String msg){
		log.info(msg);
	}
	
	public boolean isDebugEnabled(){
		return log.isDebugEnabled();
	}
	
	public void warn(String msg){
		log.warn(msg);
	}

}
