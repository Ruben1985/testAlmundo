package co.com.almundo.callcenter.interfaces;

import javax.ejb.Local;

@Local
public interface RecepcionMensajeLocal {
	
	void addOperario(String mensaje);
	
	void addSupervisor(String mensaje);
	
	void addDirector(String mensaje);
	
	int sizeListOperario();
	
	int sizeListSupervisor();
	
	int sizeListDirector();
}

