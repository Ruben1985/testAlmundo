package co.com.almundo.callcenter.model;

import co.com.almundo.callcenter.commons.LoggerUtil;

public abstract class Employee {

	private String cargo;
	private boolean disponible;
	private String message;

	private LoggerUtil logger = new LoggerUtil(Employee.class);

	public abstract void atenderLlamada();

	public void timeInCall() {
		int valorEntero = (int) Math.floor(Math.random()*(10-5+1)+5);
		try {
			Thread.sleep(new Long(valorEntero) * 1000);
		} catch (InterruptedException e) {
			logger.error("Error ejecutando metodo timeInCall ", e);
		}
	}
	
	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public boolean isDisponible() {
		return disponible;
	}

	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
