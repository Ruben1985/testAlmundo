package co.com.almundo.callcenter.model;

public class Director extends Employee{

	public Director(String mensaje) {
		setMessage(mensaje);
	}

	@Override
	public void atenderLlamada() {
		timeInCall();
	}

}
