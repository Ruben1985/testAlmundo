package co.com.almundo.callcenter.model;

public class Operario extends Employee{

	public Operario(String message) {
		setMessage(message);
	}
	
	@Override
	public void atenderLlamada() {
		timeInCall();
	}

}
