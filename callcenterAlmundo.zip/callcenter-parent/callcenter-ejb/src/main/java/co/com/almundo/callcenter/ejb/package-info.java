/**
 * 
 */
/**
 * @author lmarin
 *
 */
package co.com.almundo.callcenter.ejb;