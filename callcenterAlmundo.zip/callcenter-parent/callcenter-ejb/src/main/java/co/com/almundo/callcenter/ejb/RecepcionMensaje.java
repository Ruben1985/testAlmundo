package co.com.almundo.callcenter.ejb;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.ejb.Singleton;

import co.com.almundo.callcenter.interfaces.RecepcionMensajeLocal;
import co.com.almundo.callcenter.model.Director;
import co.com.almundo.callcenter.model.Operario;
import co.com.almundo.callcenter.model.Supervisor;

@Singleton
public class RecepcionMensaje implements RecepcionMensajeLocal {

	Set<Operario> operarios = new LinkedHashSet<>();
	Set<Supervisor> supervisores = new LinkedHashSet<>();
	Set<Director> directores = new LinkedHashSet<>();

	public RecepcionMensaje() {
		super();
	}

	public void addOperario(String mensaje) {
		Operario operario = new Operario(mensaje);
		operarios.add(operario);
		operario.atenderLlamada();
		operarios.remove(operario);
	}

	@Override
	public void addSupervisor(String mensaje) {
		Supervisor supervisor = new Supervisor(mensaje);
		supervisores.add(supervisor);
		supervisor.atenderLlamada();
		supervisores.remove(supervisor);
	}

	@Override
	public void addDirector(String mensaje) {
		Director director = new Director(mensaje);
		directores.add(director);
		director.atenderLlamada();
		directores.remove(director);
	}

	@Override
	public int sizeListOperario() {
		return operarios.size();
	}

	@Override
	public int sizeListSupervisor() {
		return supervisores.size();
	}

	@Override
	public int sizeListDirector() {
		return directores.size();
	}

}
