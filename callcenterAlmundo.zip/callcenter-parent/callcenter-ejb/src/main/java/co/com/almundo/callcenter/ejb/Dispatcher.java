package co.com.almundo.callcenter.ejb;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import co.com.almundo.callcenter.commons.LoggerUtil;
import co.com.almundo.callcenter.interfaces.RecepcionMensajeLocal;

/**
 * Message-Driven Bean implementation class for: Dispatcher
 */
@Stateless
public class Dispatcher extends Thread {

	LoggerUtil logger = new LoggerUtil(Dispatcher.class);

	@Resource
	private ConnectionFactory connectionFactory;

	@Resource
	private Queue callCenterQueue;

	@EJB
	private RecepcionMensajeLocal controlador;

//	Total de operarios contratados
	private static final int TOTAL_OPERARIOS = 4;
//	Total de supervisores contratados
	private static final int TOTAL_SUPERVISOR = 4;
//	Total de directores contratados
	private static final int TOTAL_DIRECTOR = 2;
//	Mensaje de satisfacción de la llamada.
	private static final String MESSAGES_SUCCESSFUL = "LLAMADA FINALIZADA";

	/**
	 * Default constructor.
	 */
	public Dispatcher() {
	}

	/**
	 * Clase que carga los mensajes en la cola.
	 * 
	 * @param text texto del mensaje
	 * @throws JMSException
	 */
	public void sendMessage(String text) throws JMSException {
		Connection connection = null;
		Session session = null;
		try {
			connection = connectionFactory.createConnection();
			// Connection is get from ConnectionFactory instance and it is started.
			connection.start();
			// Creates a session to created connection.
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			// Creates a MessageProducer from Session to the Queue.
			MessageProducer producer = session.createProducer(callCenterQueue);
			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
			TextMessage message = session.createTextMessage(text);
			// Tells the producer to send the message
			producer.send(message);
			Dispatcher other = new Dispatcher();
			other.start();
		} finally {
			if (session != null)
				session.close();
			if (connection != null)
				connection.close();
		}
	}
	
	@Override
	public void run() {
		try {
			dispatchCall();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Procesa los mensajes cargados en la cola.
	 * 
	 * @return Mensaje de satisfacción
	 * @throws JMSException
	 */
	public String dispatchCall() throws JMSException {
		Connection connection = null;
		Session session = null;
		MessageConsumer consumer = null;
		try {
			connection = connectionFactory.createConnection();
			connection.start();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(callCenterQueue);
//			Espera por el mensaje con un timeout. TextMessage es recibido por el consumidor y espera a ser procesado.
			TextMessage message = (TextMessage) consumer.receive();
			String mensaje = message.getText();

			if (controlador.sizeListOperario() < TOTAL_OPERARIOS) {
				controlador.addOperario(mensaje);
			} else if (controlador.sizeListSupervisor() < TOTAL_SUPERVISOR) {
				controlador.addSupervisor(mensaje);
			} else if (controlador.sizeListDirector() < TOTAL_DIRECTOR) {
				controlador.addDirector(mensaje);
			} else {
				logger.info("Todos nuestros empleados se encuentran ocupados, intente m�s tarde.");
			}
		} finally {
			if (consumer != null)
				consumer.close();
			if (session != null)
				session.close();
			if (connection != null)
				connection.close();
		}
		return MESSAGES_SUCCESSFUL;
	}

}
