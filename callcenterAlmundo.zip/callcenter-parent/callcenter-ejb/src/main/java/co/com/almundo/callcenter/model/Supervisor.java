package co.com.almundo.callcenter.model;

public class Supervisor extends Employee{

	
	
	public Supervisor(String mensaje) {
		setMessage(mensaje);
	}

	@Override
	public void atenderLlamada() {
		timeInCall();
	}

}
