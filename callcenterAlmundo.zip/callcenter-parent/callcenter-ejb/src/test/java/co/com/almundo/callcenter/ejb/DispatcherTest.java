package co.com.almundo.callcenter.ejb;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.embeddable.EJBContainer;
import javax.jms.ConnectionFactory;

import org.junit.Assert;
import org.junit.Test;

import junit.framework.TestCase;

public class DispatcherTest extends TestCase {

	@Resource
	private ConnectionFactory connectionFactory;

	@EJB
	private Dispatcher callCenterDispatcher;
	
	private static final String MESSAGE = "mensaje de solicitud apoyo de Call Center";
	private static final String MESSAGES_SUCCESSFUL = "LLAMADA FINALIZADA";
	
	@Test
	public void test() throws Exception {
		EJBContainer.createEJBContainer().getContext().bind("inject", this);
		for (int i = 0; i < 10; i++) {
			callCenterDispatcher.sendMessage(MESSAGE);
			Assert.assertEquals(MESSAGES_SUCCESSFUL, callCenterDispatcher.dispatchCall());
		}
	}

}
